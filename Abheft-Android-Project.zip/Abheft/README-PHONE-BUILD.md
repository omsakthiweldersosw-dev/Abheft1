# Build Abheft APK using only your Android phone

You do not need a PC. This project includes a GitHub Actions workflow that builds the APK in the cloud.

1. Download and extract `Abheft-Android-Project.zip` using your phone's Files app. If extracting is awkward, upload the ZIP directly to a new GitHub repository is not supported by GitHub's normal upload UI; use a phone ZIP/file manager and GitHub's web interface to upload the extracted files.
2. In Chrome, sign in to GitHub and create a new repository named `Abheft`.
3. Upload the extracted project files/folders into the repository, including `.github/workflows/build-apk.yml`. Make sure the repository root contains `settings.gradle`, `build.gradle`, and the `app` folder.
4. Open the repository's **Actions** tab and select **Build Abheft APK**. If prompted, enable workflows, then tap **Run workflow**.
5. Wait for the workflow to finish successfully. Open the completed workflow run, scroll to **Artifacts**, and download `Abheft-debug-apk`.
6. Extract the artifact ZIP on your phone. Tap `app-debug.apk` to install. Android may ask you to allow installs from that browser or file manager; only allow it for this file if you trust the source.

Abheft stores transactions and preferences locally inside the app using Android WebView local storage. Uninstalling the app or clearing app storage can erase that data. Export CSV regularly for backup.
