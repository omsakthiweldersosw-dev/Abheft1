# Abheft Android App

Apple-inspired personal budget and expense tracker. The app stores transactions, budgets, and preferences locally using the WebView DOM storage (`localStorage`) inside the app's private data area. No account, server, or bank connection is required.

## Build an APK

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open the `Abheft` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Local storage notes
- Data is saved on this device within the app's private storage; it does not sync to another phone.
- Clearing app storage or uninstalling the app can erase saved data. Use **Profile > Export transactions as CSV** for a backup.
- The initial transactions are demo data and can be removed individually or reset.
- The app has no bank integration and does not collect data remotely.
